//onboard LED_blinking for intel galileo gen 2

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int main() {
	int fdexport, fd30, fd46, fd7;
	//GPIO EXPORT
	fdexport = open("/sys/class/gpio/export", O_WRONLY);
	if(fdexport < 0) {
		printf("gpio export open failed \n");
	}
	write(fdexport,"30",2);    // gpio30 is Level shifter GPIO for IO13 & one of the onboard LED 
				   //(GPIO30 = 1 means direction in for onboard LED && GPIO30 = 0 means direction out for onboard LED) 
	write(fdexport,"46",2);    // gpio46 - MUX for IO13 & one of the onboard LED (we use it to select GPIO7 in MUX)
	write(fdexport,"7",2);     // gpio7 - linux gpio pin which is connected with IO13 & one of the onboard LED
	close(fdexport);

	
	//direction selection
	fd30 = open("/sys/class/gpio/gpio30/direction", O_WRONLY);
	if(fd30 < 0) {
		printf("gpio30 direction open failed \n");
	}
	fd46 = open("/sys/class/gpio/gpio46/direction", O_WRONLY);
	if(fd46 < 0) {
		printf("gpio46 direction open failed \n");
	}
	fd7 = open("/sys/class/gpio/gpio7/direction", O_WRONLY);
	if(fd7 < 0) {
		printf("gpio7 direction open failed \n");
	}
	write(fd30,"out",3);       //setting direction to out
	write(fd46,"out",3);
	write(fd7,"out",3);



	fd30 = open("/sys/class/gpio/gpio30/value", O_WRONLY);
	if(fd30 < 0) {
		printf("gpio30 value open failed \n");
	}
	fd46 = open("/sys/class/gpio/gpio46/value", O_WRONLY);
	if (fd46 < 0) {
		printf("gpio46 value open failed \n");
	}
	fd7 = open("/sys/class/gpio/gpio7/value", O_WRONLY);
	if (fd7 < 0) {
		printf("gpio7 value open failed \n");
	}
	write(fd30,"0",1);  // selects direction
	write(fd46,"0",1);  // selects GPIO 7
	write(fd7,"0",1);   // initial value 0 of GPIO 7

	while(1) {
		write(fd7,"1",1);
		usleep(300000);
		write(fd7,"0",1);
		usleep(300000);
	}
}
